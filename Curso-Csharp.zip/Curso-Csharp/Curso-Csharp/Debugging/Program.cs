﻿using System;

namespace Debugging
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             Tópicos
                - F9 - marcar/desmarcar breakpoint
                - F5 - iniciar/continuar o debug
                - F10 - executar um passo (pula função)
                - F11 - executar um passo (entra na função)
                - SHIFT+F11 - sair do método e execução
                - SHIFT+F5 - parar debug
            Janelas
                - Watch (expressões personalizadas)
                - Autos (expressões "interessantes" detectadas pelo VS)
                - Locals (variáveis locais)
            */
        }
    }
}
