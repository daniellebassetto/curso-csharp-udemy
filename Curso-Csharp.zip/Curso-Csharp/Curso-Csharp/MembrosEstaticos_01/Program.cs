﻿using System;

namespace MembrosEstaticos_01 {
    internal class Program {
        static void Main(string[] args) {
            
            /* 
            
            MEMBROS ESTÁTICOS
            
            membros = atributos e métodos

            Também chamados de membros de classe, em oposição a membros de instância

            São membros que fazem sentido independentemente de objetos. 
            Não precisam do objeto para serem chamados. São chamados a partir do próprio nome da classe.

            Aplicações comuns: classes utilitárias (ex: Math.Sqrt), declaração de constantes

            Uma classe que possui soemnte membros estáticos pode ser uma classe estática
            também. Esta classe não poderá ser instanciada.
             
             */
        }
    }
}
