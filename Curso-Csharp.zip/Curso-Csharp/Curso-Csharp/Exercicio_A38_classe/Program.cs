﻿using System;

namespace Exercicio_A38_classe
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
