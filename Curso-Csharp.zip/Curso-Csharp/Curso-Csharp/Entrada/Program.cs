﻿using System;
using System.Globalization;

namespace Entrada
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Comando: Console.ReadLine()
                Lê a entrada paadrão até a quebra de linha
                Retorna os dados na forma de string
            */

            string frase = Console.ReadLine();
            string x = Console.ReadLine();
            string y = Console.ReadLine();
            string z = Console.ReadLine();

            string s = Console.ReadLine();
            string[] v = s.Split(' ');  // Recorta a variável s com base no espaço em branco
            // Ou apago 'string s' e apenas coloco string[] = Console.ReadLine().Split(' ');
            string a = v[0];  // Guardando o primeiro recorte em a
            string b = v[1];  // Guardando o segundo recorte em b
            string c = v[2];  // Guardando o terceiro recorte em c


            Console.WriteLine($"Você digitou: {frase}");
            Console.WriteLine($"Você digitou: {x}");
            Console.WriteLine($"Você digitou: {y}");
            Console.WriteLine($"Você digitou: {z}");
            Console.WriteLine($"Você digitou: {a}");
            Console.WriteLine($"Você digitou: {b}");
            Console.WriteLine($"Você digitou: {c}");

            int n1 = int.Parse(Console.ReadLine());  // é necessário realizar essa conversão pois o ReadLine lê str
            char ch = char.Parse(Console.ReadLine());
            double n2 = double.Parse(Console.ReadLine()); // Quando insiro um valor com ponto, não aparece! Com vírgula sim
            double n3 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);  // Colocando ponto 

            string[] vet = Console.ReadLine().Split(' ');
            string nome = vet[0];
            char sexo = char.Parse(vet[1]);
            int idade = int.Parse(vet[2]);
            double altura = double.Parse(vet[3], CultureInfo.InvariantCulture);

            Console.WriteLine("Vôcê digitou: ");
            Console.WriteLine(n1);
            Console.WriteLine(ch);
            Console.WriteLine(n2);
            Console.WriteLine(n3.ToString(CultureInfo.InvariantCulture)); // Imprimindo com ponto
            Console.WriteLine(nome);
            Console.WriteLine(sexo);
            Console.WriteLine(idade);
            Console.WriteLine(altura.ToString("F2", CultureInfo.InvariantCulture));
        }
    }
}
