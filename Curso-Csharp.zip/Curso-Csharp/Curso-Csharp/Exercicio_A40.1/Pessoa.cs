﻿namespace Exercicio_A40._1 {
    internal class Pessoa {

        public string Nome;
        public int Idade;
    }
}
