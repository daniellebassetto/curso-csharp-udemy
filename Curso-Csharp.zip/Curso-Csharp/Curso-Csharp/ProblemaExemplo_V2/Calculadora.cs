﻿using System;

namespace ProblemaExemplo_V2 {
    internal class Calculadora {

        public double Pi = 3.14; // atributo

        public double Circunferencia(double r) { // método
            return 2.0 * Pi * r;
        }

        public double Volume(double r) {
            return 4.0 / 3.0 * Pi * Math.Pow(r, 3);
        }
    }
}
