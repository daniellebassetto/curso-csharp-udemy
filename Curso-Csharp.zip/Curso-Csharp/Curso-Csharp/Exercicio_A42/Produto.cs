﻿using System.Globalization;

namespace Exercicio_A42 {
    internal class Produto {

        public string Nome;
        public double Preco;
        public int Quantidade;

        public double ValorTotalEmEstoque() {
            return Preco * Quantidade;
        }

        public void AdicionarProdutos(int quantidade) {
            Quantidade += quantidade;
        }

        public void RemoverProdutos(int quantidade) {
            Quantidade -= quantidade;
        }

        override public string ToString() {
            return Nome
                + ", $ "
                + Preco.ToString("F2", CultureInfo.InvariantCulture)
                + ", "
                + Quantidade
                + " unidades, Total: $ "
                + ValorTotalEmEstoque().ToString("F2", CultureInfo.InvariantCulture);
        }

        /*
            TODA CLASSE EM C# É UMA SUBCLASSE DA CLASSE OBJECT, OBJECT POSSUI OS SEGUINTES MÉTODOS:
            GETTYPE - RETORNA O TIPO DO OBJETO
            EQUALS - COMPARA SE O OBJETO É IGUAL AO OUTRO
            GETHASHCODE - RETORNA UM CÓDIGO HASH DO OBJETO
            TOSTRING - CONVERTE O OBJETO PARA STRING
        */
    }
}
