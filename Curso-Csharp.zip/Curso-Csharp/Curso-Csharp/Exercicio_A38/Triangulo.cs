﻿using System;

// colocar namespace da classe
namespace Exercicio_A38 {

    // colocar nome da classe
    internal class Triangulo {

        public double A;
        public double B;
        public double C; // atributos da classe

        // criando um metodo (função) para o calculo das áreas
        public double Area() {
            // o double significa o tipo de dado que o método retorna, se o método não retorna nada, usa-se "void", o () é a lista de parâmetros do método
            double p = (A + B + C) / 2.0;
            // return Math.Sqrt(p * (p - A) * (p - B) * (p - C)); ou:
            double raiz = Math.Sqrt(p * (p - A) * (p - B) * (p - C));
            return raiz;



        /* ANÁLISE DE AULA
        
            "public" = indica que o atributo ou método pode ser utilizado em outros arquivos
            "using System" = importação de dependências

            É possível utilizar o Projeto da classe (UML) para projetá-la antes de programá-la
            Benefícios de utilizar métodos e classes: reaproveitamento do código, delegação de responsabilidades
        */
         

        }
    }
}
