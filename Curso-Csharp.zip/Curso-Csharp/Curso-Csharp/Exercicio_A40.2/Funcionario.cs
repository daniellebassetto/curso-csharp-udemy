﻿namespace Exercicio_A40._2 {
    internal class Funcionario {

        public string Nome;
        public double Salario;
    }
}
