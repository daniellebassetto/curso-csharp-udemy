﻿using System;

namespace ProblemaExemplo_V2 {
    internal class Calculadora {

        public static double Pi = 3.14; // inseri o static para não precisar referenciar objeto, já que não muda independente da calculadora

        public static double Circunferencia(double r) { // método
            return 2.0 * Pi * r;
        }

        public static double Volume(double r) {
            return 4.0 / 3.0 * Pi * Math.Pow(r, 3);
        }
    }
}

